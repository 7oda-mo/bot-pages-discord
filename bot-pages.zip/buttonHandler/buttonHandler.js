const { Client, MessageButton, MessageActionRow } = require('discord.js');

const client = new Client({ intents: [32723] });
const loveButtonClicked = new Set();
const okButtonClicked = new Set();

const loveButton = new MessageButton()
  .setCustomId('love_button')
  .setLabel(`😍 0`)
  .setStyle('PRIMARY');

const okButton = new MessageButton()
  .setCustomId('ok_button')
  .setLabel(`👌 0`)
  .setStyle('PRIMARY');

const sendButton = new MessageButton()
  .setCustomId('send_button')
  .setLabel('Send code')
  .setStyle('SECONDARY');

const buttonRow = new MessageActionRow().addComponents(loveButton, okButton, sendButton);

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  // Create a new message with the buttons
  const buttonsMessage = await message.reply({
    content: 'This is a test message with buttons!',
    components: [buttonRow],
  });

  // Listen for button interactions
  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.message.id !== buttonsMessage.id) return;

    const user = interaction.user;

    // Check if the user has already interacted with the love button or the ok button
    const loveButtonAlreadyClicked = loveButtonClicked.has(user.id);
    const okButtonAlreadyClicked = okButtonClicked.has(user.id);

    if (interaction.customId === 'love_button' && !loveButtonAlreadyClicked) {
      loveButtonClicked.add(user.id);
      // Increment the love counter
      const button = interaction.component;
      const count = parseInt(button.label.split(' ')[1]) + 1;
      button.setLabel(`😍 ${count}`);
      await interaction.update({ components: [buttonRow] });
    } else if (interaction.customId === 'ok_button' && !okButtonAlreadyClicked) {
      okButtonClicked.add(user.id);
      // Increment the ok counter
      const button = interaction.component;
      const count = parseInt(button.label.split(' ')[1]) + 1;
      button.setLabel(`👌 ${count}`);
      await interaction.update({ components: [buttonRow] });
    } else if (interaction.customId === 'send_button') {
      const codeEmbed = interaction.message.embeds[0]; // Get the embedded code
      const codeContent = codeEmbed.description; // Get the code content

      // Send the code content to the user in DMs
      await user.send({ content: codeContent });

      // Reply with a confirmation message
      await interaction.reply({ content: 'The code has been sent to your DM.', ephemeral: true });
    }
  });
});